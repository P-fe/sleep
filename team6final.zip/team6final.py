import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import statsmodels.api as sm
from statsmodels.formula.api import ols
from scipy.stats import shapiro
from statsmodels.stats.diagnostic import het_breuschpagan

dat = pd.read_csv('./data/Sleep_Efficiency.csv')
df = pd.DataFrame(dat)

# 변수 정의
# ID  : 식별자
# Age : 나이
# Gender : 성별
# Bedtime : 취침시간
# Wakeup time : 기상시간
# Sleep duration : 총수면시간(단위 : 시간)
# Sleep efficiency : 수면 효율(침대에 누워있을시간 대비 잠자는 시간)
# REM sleep percentage : 램 수면 시간 비율
# Deep sleep percentage : 깊은 수면 시간 비율
# Light sleep percentage : 얕은 수면 시간 비율 
# Awakenings : 깬 횟수
# Caffeine consumption : 카페인 셥취량
# Alcohol consumption : 알코올 섭취량
# Smoking status : 흡연 여부
# Exercise frequency : 운동 빈도


# 데이터 알아보기
df.isnull().sum()

# Awakenings, Caffeine consumption,Alcohol consumption,Exercise frequency에서 nan값 발생
# 각각 nan값은 최빈값으로 대체하기 
df['Awakenings'].mode()     # 최빈값 1
df['Caffeine consumption'].mode()  # 최빈값 0
df['Alcohol consumption'].mode()   # 최빈값 0
df['Exercise frequency'].mode()   # 최빈값 3

df['Awakenings'] = df['Awakenings'].fillna(1)
df['Caffeine consumption'] = df['Caffeine consumption'].fillna(0)
df['Alcohol consumption'] = df['Alcohol consumption'].fillna(0)
df['Exercise frequency'] = df['Exercise frequency'].fillna(3)

# 시간대 30분 단위로 자르기
df['Bedtime'] = pd.to_datetime(df['Bedtime'], errors='coerce')
df['bed_halfhour'] = df['Bedtime'].dt.hour + (df['Bedtime'].dt.minute >= 30) * 0.5
df['bed_halfhour'].value_counts().sort_index()


##################################################################################
# # 운동 빈도가 수면 효율에 주는 영향
# 운동 빈도수
# 운동 빈도를 구간화해서 (예: 없음, 중간, 자주) 그룹별 
Exer_frq = df['Exercise frequency'].unique()
Exer_frq.sort()
print('운동빈도 수 : ', Exer_frq)
Ef_Lsp = df.groupby('Exercise frequency')['Light sleep percentage'].mean()
Ef_SE = df.groupby('Exercise frequency')['Sleep efficiency'].mean()

# 운동빈도에 따른 light sleep 그래프
norm_values = (Ef_Lsp .values - min(Ef_Lsp .values)) / (max(Ef_Lsp .values) - min(Ef_Lsp .values))
colors = [(0.56, 0.93, 0.56, alpha) for alpha in norm_values]
plt.bar(Ef_Lsp .index, Ef_Lsp .values, color=colors, edgecolor='black')
plt.title('Light sleep by E.F')
plt.xlabel('Frequency')
plt.ylabel('Light sleep')
plt.ylim(10,35)
plt.show()
# 운동빈도에 따른 수면 효율 그래프
norm_values = (Ef_SE.values - min(Ef_SE.values)) / (max(Ef_SE.values) - min(Ef_SE.values))
colors = [(0.56, 0.93, 0.56, alpha) for alpha in norm_values]
plt.bar(Ef_SE.index, Ef_SE.values, color=colors, edgecolor='black')
plt.title('Sleep Efficiency by E.F')
plt.xlabel('Frequency')
plt.ylabel('Sleep Efficiency')
plt.ylim(0.5,1)
plt.show()


## light sleep과 운동빈도 정규성 검정
model = ols("Q('Light sleep percentage') ~ Q('Exercise frequency')", data=df).fit()
residuals = model.resid
sm.qqplot(residuals, line='45', fit=True)
plt.title("Q-Q Plot of Residuals")
plt.xlabel("Theoretical Quantiles")
plt.ylabel("Sample Quantiles")
plt.grid(True)
plt.show()

## Sleep dfficiency와 운동빈도 정규성 검정
model = ols("Q('Sleep efficiency') ~ Q('Exercise frequency')", data=df).fit()
residuals = model.resid
sm.qqplot(residuals, line='45', fit=True)
plt.title("Q-Q Plot of Residuals")
plt.xlabel("Theoretical Quantiles")
plt.ylabel("Sample Quantiles")
plt.grid(True)
plt.show()
##################################################################################

smokers = df[df['Smoking status']=='Yes']
nonsmokers = df[df['Smoking status']=='No']

smokers["Sleep efficiency"].mean()
nonsmokers["Sleep efficiency"].mean()

# 흡연여부의 정규성 검정
from scipy.stats import shapiro
result1 = shapiro(smokers['Sleep efficiency'])
result2 = shapiro(nonsmokers['Sleep efficiency'])
print('pvalue : ', result1.pvalue)
print('pvalue : ', result2.pvalue)
# 샤피로 윌크 검정 결과 귀무가설 기각
# 즉, 정규성을 따르지 않는다 
# 비모수 검정을 사용해야한다.

sns.kdeplot(smokers['Sleep efficiency'], label='Smoker', shade=True)
sns.kdeplot(nonsmokers['Sleep efficiency'], label='Non-smoker', shade=True)
plt.title("수면 효율 분포 (흡연 vs 비흡연)")
plt.legend()
plt.show()
# 그림으로 그려보면 정규분포를 따르지 않는것을 알 수 있다.


# 흡연자와 비흡연자간의 수면 효율을 검정
from scipy.stats import mannwhitneyu
result = mannwhitneyu(smokers['Sleep efficiency'], nonsmokers['Sleep efficiency'], alternative='two-sided')
print("p-value:", result.pvalue)
# 만휘트니 검정결과 p_value 0.000 < 0.05 이므로 귀무가설 기각 
# 즉, 흡연자와 비흡연자간의 수면 효율 데이터에 유의한 차이가 존재한다.


# 흡연여부 및 Light sleep간 정규성 검정
smokers["Light sleep percentage"].mean()
nonsmokers["Light sleep percentage"].mean()
#정규분포 X
from scipy.stats import shapiro
result1 = shapiro(smokers['Light sleep percentage'])
result2 = shapiro(nonsmokers['Light sleep percentage'])
print('smoker pvalue : ', result1.pvalue)
print('non_smoker pvalue : ', result2.pvalue)
# 샤피로 윌크 검정 결과 귀무가설 기각
# 즉, 정규성을 따르지 않는다 
# 비모수 검정을 사용해야한다.

sns.kdeplot(smokers['Light sleep percentage'], label='Smoker', shade=True)
sns.kdeplot(nonsmokers['Light sleep percentage'], label='Non-smoker', shade=True)
plt.title("얕은 수면 분포 (흡연 vs 비흡연)")
plt.legend()
plt.show()
# 그림으로 그려보면 정규분포를 따르지 않는것을 알 수 있다.

# 흡연자와 비흡연자간의 Light sleep % 검정
from scipy.stats import mannwhitneyu
result = mannwhitneyu(smokers['Light sleep percentage'], nonsmokers['Light sleep percentage'], alternative='two-sided')
print('Light_pvalue : ', result.pvalue)
# 만휘트니 검정결과 p_value 0.000 < 0.05 이므로 귀무가설 기각 
# 즉, 흡연자와 비흡연자간의 Light sleep 데이터에 유의한 차이가 존재한다.

##############################################################

# 1.알콜 기준 sleep efficiency 코드

# 2. Alcohol Group 컬럼 생성 (0.0 vs Other)
def alcohol_binary_group(val):
    if val == 0.0:
        return '0.0'
    else:
        return 'Other'
df['Alcohol consumption'].unique()
df['Alcohol Binary Group'] = df['Alcohol consumption'].apply(alcohol_binary_group)
# 취한 사람과 안취한 사람간의 데이터 구분

# 3. 그룹별 Sleep efficiency 평균 계산
group_means = df.groupby('Alcohol Binary Group')['Sleep efficiency'].mean()

# 4. 막대 그래프 시각화
plt.figure(figsize=(6, 5))
group_means.loc[['0.0', 'Other']].plot(
    kind='bar',
    color=['royalblue', 'lightcoral'],
    edgecolor='black'
)
plt.title("Average Sleep Efficiency by Alcohol Group (0.0 vs Other)")
plt.xlabel("Alcohol Consumption Group")
plt.ylabel("Sleep Efficiency")
plt.ylim(0, 1)
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# 알콜 기준 light sleep percentage

# 2. Alcohol 그룹 나누기: 0.0 vs Other
def alcohol_binary_group(val):
    if val == 0.0:
        return '0.0'
    else:
        return 'Other'

df['Alcohol Binary Group'] = df['Alcohol consumption'].apply(alcohol_binary_group)

# 3. 그룹별 평균 Light sleep percentage 계산
light_sleep_means = df.groupby('Alcohol Binary Group')['Light sleep percentage'].mean()

# 4. 막대 그래프 그리기
plt.figure(figsize=(6, 5))
light_sleep_means.loc[['0.0', 'Other']].plot(
    kind='bar',
    color=['mediumaquamarine', 'indianred'],
    edgecolor='black'
)
plt.title("Average Light Sleep Percentage by Alcohol Group (0.0 vs Other)")
plt.xlabel("Alcohol Consumption Group")
plt.ylabel("Light Sleep Percentage")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# 알콜 기준 light sleep percentage 정규성 검증 
import statsmodels.api as sm
light_sleep_data = df['Light sleep percentage']
# 3. QQ-Plot 그리기
plt.figure(figsize=(6, 5))
sm.qqplot(light_sleep_data, line='s')
plt.title("QQ-Plot: Light Sleep Percentage (전체 알코올 섭취 포함)")
plt.tight_layout()
plt.show()

# 독립변수 알콜과 수면 효율  종속변수 light sleep percentage 회귀 분석

df_reg = df[['Alcohol consumption','Sleep efficiency', 'Light sleep percentage']]

# 3. 독립 변수와 종속 변수 설정
X = sm.add_constant(df_reg[['Alcohol consumption','Sleep efficiency']])  # 독립 변수에 상수항 추가
y = df_reg['Light sleep percentage']

# 4. 회귀 모델 적합
model = sm.OLS(y, X).fit()

# 5. 회귀 결과 출력
print(model.summary())
